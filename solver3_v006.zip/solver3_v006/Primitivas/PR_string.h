/*
 * PR_string.h
 *
 *  Created on: Nov 2, 2017
 *      Author: fede
 */

#ifndef PR_STRING_H_
#define PR_STRING_H_

#include "string.h"
#include "Solver3.h"

#define INITIAL		0
#define CONNECT		1
#define ANALYZE		2
#define CHECK		3

uint8_t comunication(void);

#endif /* PR_STRING_H_ */
