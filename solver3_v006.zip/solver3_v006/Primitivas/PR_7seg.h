/*
 * PR_7seg.h
 *
 *  Created on: Oct 27, 2017
 *      Author: fede
 */

#ifndef PR_7SEG_H_
#define PR_7SEG_H_

#include "PR_Crono.h"

#define MILI 0
#define SEGUNDOS 1

void Display_Number(uint16_t ,uint8_t);

#endif /* PR_7SEG_H_ */
