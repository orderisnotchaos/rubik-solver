/*
 * FW_Stepper.h
 *
 *  Created on: 2 de set. de 2017
 *      Author: diego
 */

#ifndef FW_STEPPER_H_
#define FW_STEPPER_H_

#include "RegsLPC17xx.h"

void FW_dirMotor(void);
void FW_motor(void);
void FW_motorLineal(void);

#endif /* FW_STEPPER_H_ */
