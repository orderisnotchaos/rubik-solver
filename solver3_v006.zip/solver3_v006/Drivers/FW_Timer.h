/*
 * FW_Timer.h
 *
 *  Created on: 15/08/2013
 *      Author: Pablo
 */

#ifndef FW_TIMER_H_
#define FW_TIMER_H_

#include "RegsLPC17xx.h"

//#define TIMER0_PCLK	25000000

void TIMER0_Init(uint32_t, uint32_t);

#endif /* FW_TIMER_H_ */
