/*
 * 7_Seg.h
 *
 *  Created on: 8 de ago. de 2017
 *      Author: diego
 */

#include "Solver3.h"

extern uint8_t Tabla[11];

void barridoDisplay(void);
