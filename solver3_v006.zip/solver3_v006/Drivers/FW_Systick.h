/*
 * FW_Systick.h
 *
 *  Created on: 10/06/2015
 *      Author: Pablo
 */

#ifndef FW_SYSTICK_H_
#define FW_SYSTICK_H_

//#include "RegsLPC17xx.h"

void Systick_Init(uint32_t useg);

#endif /* FW_SYSTICK_H_ */
